package brazillianforgers.lib.RecipeHelper;

public interface ICraftable
{
	public Recipe[] getRecipes();
}
