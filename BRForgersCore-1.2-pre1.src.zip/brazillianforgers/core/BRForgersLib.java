package brazillianforgers.core;

import brazillianforgers.lib.ObjectStorage;

/**
 * BRForgersLib: A "Common" ObjectLib for Mod Interaction
 */
public class BRForgersLib
{
	public static ObjectStorage variables = new ObjectStorage();
	public static boolean isClient = false;
	public static String playername = "";
}
