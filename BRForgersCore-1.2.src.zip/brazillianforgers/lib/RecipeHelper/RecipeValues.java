package brazillianforgers.lib.RecipeHelper;

import java.util.ArrayList;
import java.util.Arrays;

import net.minecraft.item.ItemStack;

/**
 * Easier Recipe Value Array Generator (WIP)
 */
public class RecipeValues {
	public RecipeValues() {}
	
	public ArrayList<RecipeValue> values = new ArrayList<RecipeValue>();
	
	public RecipeValues add(RecipeValue... recipeValues)
	{
		values.addAll(Arrays.asList(recipeValues));
		return this;
	}
	
	public RecipeValues add(char id, ItemStack item)
	{
		values.add(new RecipeValue(id, item));
		return this;
	}
	
	public RecipeValue[] getAll()
	{
		return (RecipeValue[]) values.toArray();
	}
}
