package brazillianforgers.lib.RecipeHelper;

import net.minecraft.item.ItemStack;

/**
 * Shaped Recipes Inputs<br>
 * Used by Recipe() when on Shaped-Recipes Mode 
 * @author TheFreeHigh
 *
 */
public class RecipeValue
{
	/**
	 * The Reference of the Item in the Crafting 
	 */
	public char id;
	
	/**
	 * The Item that the ID represents in the Crafting
	 */
	public ItemStack item;
	
	/**
	 * Recipe Value Definition. Used by {@link Recipe}() to Define the Values of a Shaped Recipe
	 * @param id Indentification {@link Character}
	 * @param item {@link ItemStack} Value
	 */
	public RecipeValue(char id, ItemStack item)
	{
		this.id = id;
		this.item = item;
	}
}
