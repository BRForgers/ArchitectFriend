package brazillianforgers.lib;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import net.minecraftforge.common.config.Configuration;

/**
 * Configuration Helper for Mods (WIP)
 */
public class ConfigHelper extends ObjectStorage
{
	public Configuration conf;
	
    public ConfigHelper(File file)
    {
    	conf = new Configuration(file);
    }
    
    public ConfigHelper load()
    {
    	conf.load();
    	return this;
    }
}
