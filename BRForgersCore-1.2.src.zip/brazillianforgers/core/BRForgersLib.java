package brazillianforgers.core;

import org.apache.logging.log4j.Logger;

import brazillianforgers.lib.ObjectStorage;
import brazillianforgers.lib.SilentLogger;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.relauncher.Side;
import net.minecraft.client.Minecraft;

/**
 * BRForgersLib: A "Common" ObjectLib for Mod Interaction
 */
public class BRForgersLib
{
	public static void init()
	{
		BRForgersLib.isClient = (FMLCommonHandler.instance().getEffectiveSide() == Side.CLIENT);
		BRForgersLib.playername = BRForgersLib.isClient ? Minecraft.getMinecraft().getSession().getUsername() : "";
	}
	
	public static ObjectStorage variables = new ObjectStorage();
	public static boolean isClient = false;
	public static String playername = "";
}
