package brazillianforgers.core;

import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraftforge.common.config.Configuration;
import tv.twitch.Core;
import brazillianforgers.lib.ObjectStorage;
import brazillianforgers.lib.SilentLogger;

/**
 * BRForgersCore: Where a Lot of ~magic~ Definitions happen!
 * <br> The Core Mod itself define some variables for Common Mod Usage.
 * @author TheFreeHigh
 */
@Mod(modid = CoreLib.MODID , version = CoreLib.VERSION , name = CoreLib.MODNAME)
public class BRForgersCore
{
	@Instance(CoreLib.MODID)
	public static BRForgersCore instance;
	
	public static Logger logger;
	//static Configuration config;
	//private static ObjectStorage configLib = new ObjectStorage();
	
	@EventHandler
	public static void preInit(FMLPreInitializationEvent e)
	{
		/* Get Logger */
		logger = e.getModLog();
		
		/* Startup Log */
		logger.info("I'm Alive?");
		LogManager.getLogger("FML").info("Yup. You ARE. Now Load!");
		logger.info("Okay! Start Loading...");
		
		logger.info((FMLCommonHandler.instance().getEffectiveSide() == Side.CLIENT) ? "So, We're on a client? Oh, Hi " + Minecraft.getMinecraft().getSession().getUsername() + "!": "So, I'm on a server? Where's Everyone?");
		
		/* Get Configs */
		Configuration config = new Configuration(e.getSuggestedConfigurationFile());
		config.load();
		
		/* Start Modules */
		logger.debug("Loading PreInitialization Modules..");
		
		/* Init BRForgersLib */
		logger.debug("Loading BRForgersLib...");
		BRForgersLib.init();
		
		/* Ending PreInit */
		logger.debug("PreInit Modules Loaded!");
		
		logger.info("I think " + (BRForgersLib.isClient ? "we're" : "I'm") + " done for now.");
		if (BRForgersLib.isClient) logger.info("Also, Thanks "+ BRForgersLib.playername +", for playing with BRForgers Mods!");
	}
	
	@EventHandler
	public static void init(FMLInitializationEvent e)
	{
		//logger.debug("Loading Initialization Modules..");
		
		//logger.debug("All Init Modules Loaded!");
	}
		
	@EventHandler
	public static void postInit(FMLPostInitializationEvent e)
	{
		logger.info("Oh, it's Post Initialization. Let's Check for Updates!");
		UpdateManager.UpdateStatus s = UpdateManager.check(CoreLib.UPDATEURL, new SilentLogger(), CoreLib.VERSION, CoreLib.MODID);
		logger.info((s.connected) ? ((s.updated) ? "Yay! I'm Updated!" : "Ohh, I'm Outdated. The Latest Version is '" + s.version + "', and I'm still on '" + CoreLib.VERSION + "'. Please Update Me!") : "I can't get to Internet get the Remote Version. I'll assume I'm updated.");
	}
}
